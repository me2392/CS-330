//////////////////////////////////////////////////////////////////////////////
// shadermanager.cpp
// ============
// manage the loading and rendering of 3D scenes
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager* pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.ambientColor = m_objectMaterials[index].ambientColor;
			material.ambientStrength = m_objectMaterials[index].ambientStrength;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationX * rotationY * rotationZ * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.ambientColor", material.ambientColor);
			m_pShaderManager->setFloatValue("material.ambientStrength", material.ambientStrength);
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  LoadSceneTextures()
 *
 *  This method is used for loading the texture images
 *  for the bookshelf into memory
 ***********************************************************/
void SceneManager::LoadSceneTextures()
{
	// wood grain for the three shelves
	CreateGLTexture("textures/rusticwood.jpg", "wood");
	// dark brushed metal for the legs, the ring, the tray and the candle holders
	CreateGLTexture("textures/blackmetal.jpg", "metal");
	// light wood for the floor plane so it can reflect the light
	CreateGLTexture("textures/light wood.jpg", "floor");

	// bind the loaded textures to the texture slots
	BindGLTextures();
}

/***********************************************************
 *  DefineObjectMaterials()
 *
 *  This method is used for configuring the material
 *  settings for the objects in the scene so they react
 *  to the light sources
 ***********************************************************/
void SceneManager::DefineObjectMaterials()
{
	// wood material for the three shelves, soft low shine
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.2f);    // warm color in the shadows
	woodMaterial.ambientStrength = 0.1f;                         // how much ambient color shows
	woodMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);    // brightness added by each light
	woodMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);   // dull highlight for wood
	woodMaterial.shininess = 8.0f;                               // wide soft highlight
	woodMaterial.tag = "wood";
	m_objectMaterials.push_back(woodMaterial);

	// metal material for the legs and the ring, brighter shine
	OBJECT_MATERIAL metalMaterial;
	metalMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);   // keeps the black metal from going fully dark
	metalMaterial.ambientStrength = 0.1f;
	metalMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	metalMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);  // strong highlight for metal
	metalMaterial.shininess = 32.0f;                             // small sharp highlight
	metalMaterial.tag = "metal";
	m_objectMaterials.push_back(metalMaterial);

	// floor material, shiny enough to reflect the light off the plane
	OBJECT_MATERIAL floorMaterial;
	floorMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	floorMaterial.ambientStrength = 0.1f;
	floorMaterial.diffuseColor = glm::vec3(0.3f, 0.3f, 0.3f);   // lower since three lights add to it
	floorMaterial.specularColor = glm::vec3(0.6f, 0.6f, 0.6f);  // visible shine on the floor
	floorMaterial.shininess = 32.0f;
	floorMaterial.tag = "floor";
	m_objectMaterials.push_back(floorMaterial);

	// wax material for the pumpkin candles and the tray candles
	OBJECT_MATERIAL waxMaterial;
	waxMaterial.ambientColor = glm::vec3(0.4f, 0.3f, 0.2f);     // warm glow in the shadows
	waxMaterial.ambientStrength = 0.15f;
	waxMaterial.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	waxMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);    // soft waxy shine
	waxMaterial.shininess = 16.0f;
	waxMaterial.tag = "wax";
	m_objectMaterials.push_back(waxMaterial);

	// sand material for the sandscape, flat with almost no shine
	OBJECT_MATERIAL sandMaterial;
	sandMaterial.ambientColor = glm::vec3(0.3f, 0.25f, 0.2f);
	sandMaterial.ambientStrength = 0.1f;
	sandMaterial.diffuseColor = glm::vec3(0.45f, 0.45f, 0.45f);
	sandMaterial.specularColor = glm::vec3(0.05f, 0.05f, 0.05f); // sand barely reflects
	sandMaterial.shininess = 2.0f;
	sandMaterial.tag = "sand";
	m_objectMaterials.push_back(sandMaterial);

	// book cover material, matte with a small highlight
	OBJECT_MATERIAL bookMaterial;
	bookMaterial.ambientColor = glm::vec3(0.3f, 0.3f, 0.3f);
	bookMaterial.ambientStrength = 0.1f;
	bookMaterial.diffuseColor = glm::vec3(0.4f, 0.4f, 0.4f);
	bookMaterial.specularColor = glm::vec3(0.1f, 0.1f, 0.1f);   // paper covers are dull
	bookMaterial.shininess = 4.0f;
	bookMaterial.tag = "book";
	m_objectMaterials.push_back(bookMaterial);
}

/***********************************************************
 *  SetupSceneLights()
 *
 *  This method is used for adding and configuring the
 *  light sources for the scene. The shader adds all four
 *  lights together, so every light is set here.
 ***********************************************************/
void SceneManager::SetupSceneLights()
{
	// tell the shader to use the custom lighting
	m_pShaderManager->setBoolValue(g_UseLightingName, true);

	// light 0 - warm main light, above and in front on the left like a lamp
	m_pShaderManager->setVec3Value("lightSources[0].position", glm::vec3(-6.0f, 12.0f, 10.0f));
	m_pShaderManager->setVec3Value("lightSources[0].ambientColor", glm::vec3(0.22f, 0.15f, 0.06f));  // stronger warm color added to the scene
	m_pShaderManager->setVec3Value("lightSources[0].diffuseColor", glm::vec3(1.0f, 0.85f, 0.6f));
	m_pShaderManager->setVec3Value("lightSources[0].specularColor", glm::vec3(1.0f, 0.9f, 0.7f));
	m_pShaderManager->setFloatValue("lightSources[0].focalStrength", 32.0f);                          // tight highlight
	m_pShaderManager->setFloatValue("lightSources[0].specularIntensity", 0.05f);                      // highlight brightness

	// light 1 - cool fill light from the front right so nothing is in full shadow
	m_pShaderManager->setVec3Value("lightSources[1].position", glm::vec3(8.0f, 6.0f, 8.0f));
	m_pShaderManager->setVec3Value("lightSources[1].ambientColor", glm::vec3(0.04f, 0.05f, 0.12f));  // cool tint to contrast the warm light
	m_pShaderManager->setVec3Value("lightSources[1].diffuseColor", glm::vec3(0.6f, 0.7f, 1.0f));
	m_pShaderManager->setVec3Value("lightSources[1].specularColor", glm::vec3(0.6f, 0.7f, 1.0f));
	m_pShaderManager->setFloatValue("lightSources[1].focalStrength", 16.0f);                          // wider highlight
	m_pShaderManager->setFloatValue("lightSources[1].specularIntensity", 0.02f);                      // soft highlight

	// light 2 - warm back light behind the shelf, its reflection
	// lands on the floor in front of the shelf so the plane shines
	m_pShaderManager->setVec3Value("lightSources[2].position", glm::vec3(0.0f, 6.0f, -8.0f));
	m_pShaderManager->setVec3Value("lightSources[2].ambientColor", glm::vec3(0.05f, 0.03f, 0.0f));   // small warm glow
	m_pShaderManager->setVec3Value("lightSources[2].diffuseColor", glm::vec3(1.0f, 0.7f, 0.4f));
	m_pShaderManager->setVec3Value("lightSources[2].specularColor", glm::vec3(1.0f, 0.8f, 0.5f));
	m_pShaderManager->setFloatValue("lightSources[2].focalStrength", 8.0f);                           // wide glow on the floor
	m_pShaderManager->setFloatValue("lightSources[2].specularIntensity", 0.025f);                      // brightness of the floor shine

	// light 3 is not used, it is moved far below the scene
	// and turned off so it adds nothing to the shader
	m_pShaderManager->setVec3Value("lightSources[3].position", glm::vec3(0.0f, -100.0f, 0.0f));
	m_pShaderManager->setVec3Value("lightSources[3].ambientColor", glm::vec3(0.0f, 0.0f, 0.0f));
	m_pShaderManager->setFloatValue("lightSources[3].focalStrength", 1.0f);
	m_pShaderManager->setFloatValue("lightSources[3].specularIntensity", 0.0f);
}

/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// load the textures before drawing anything
	LoadSceneTextures();
	// define the materials and lights for the scene
	DefineObjectMaterials();
	SetupSceneLights();

	// only one instance of a particular mesh needs to be
	// loaded in memory no matter how many times it is drawn
	// in the rendered 3D scene

	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();              // legs, shelves, tray, stand and books
	m_basicMeshes->LoadTorusMesh(0.05f);       // metal ring and the sandscape frame
	m_basicMeshes->LoadCylinderMesh();         // sand disk, pumpkin stems and candles
	m_basicMeshes->LoadSphereMesh();           // pumpkin candles and flames
	m_basicMeshes->LoadTaperedCylinderMesh();  // candle holders on the tray
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// top surface of each shelf, used to set things on the shelves
	const float topShelfY = 6.025f;
	const float middleShelfY = 3.7f;
	const float bottomShelfY = 1.7f;

	// floor, bookshelf and the large ring in the center
	DrawFloor();
	DrawBookshelf();
	DrawMetalRing();

	// top shelf, sandscape on the left, tray in the middle, pumpkins on the right
	DrawSandscape(glm::vec3(-4.5f, topShelfY, 0.0f));
	DrawCandleTray(glm::vec3(0.0f, topShelfY, 0.0f));
	DrawPumpkinCandle(glm::vec3(3.6f, topShelfY, 0.2f), 0.55f);
	DrawPumpkinCandle(glm::vec3(4.9f, topShelfY, -0.1f), 0.4f);

	// small stack of books lying flat between the sandscape and the tray
	DrawBookStack(glm::vec3(-2.4f, topShelfY, 0.0f));

	// middle and bottom shelves filled with books from leg to leg
	DrawBookRow(-6.6f, 6.6f, middleShelfY, 0);
	DrawBookRow(-6.6f, 6.6f, bottomShelfY, 3);
}

/***********************************************************
 *  DrawFloor()
 *
 *  This method is used for drawing the light wood floor
 *  plane that the bookshelf stands on
 ***********************************************************/
void SceneManager::DrawFloor()
{
	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/
	// set the XYZ scale for the mesh
	scaleXYZ = glm::vec3(20.0f, 1.0f, 10.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	// set the transformations into memory to be used on the drawn meshes
	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	SetShaderTexture("floor");    // light wood floor
	SetTextureUVScale(4.0f, 2.0f);  // tile the floor so the boards are not stretched
	SetShaderMaterial("floor");   // shiny floor material to reflect the light

	// draw the mesh with transformation values
	m_basicMeshes->DrawPlaneMesh();
	/****************************************************************/
}

/***********************************************************
 *  DrawBookshelf()
 *
 *  This method is used for drawing the black metal
 *  bookshelf, four legs and three wooden shelves
 ***********************************************************/
void SceneManager::DrawBookshelf()
{
	// the four legs are the same size, only the x and z change
	// box is centered on itself so half of the 6.0 height puts it at 3.0
	glm::vec3 legPositions[4] = {
		glm::vec3(-6.75f, 3.0f, 1.25f),    // front left
		glm::vec3(6.75f, 3.0f, 1.25f),     // front right
		glm::vec3(-6.75f, 3.0f, -1.25f),   // back left
		glm::vec3(6.75f, 3.0f, -1.25f)     // back right
	};

	SetShaderTexture("metal");   // black metal frame
	// tile the metal up the leg so it is not stretched
	SetTextureUVScale(0.25f, 6.0f);
	SetShaderMaterial("metal");   // metal material for lighting

	// draw each leg with the same scale at its own spot
	for (int i = 0; i < 4; i++)
	{
		SetTransformations(
			glm::vec3(0.25f, 6.0f, 0.25f),
			0.0f, 0.0f, 0.0f,
			legPositions[i]);
		m_basicMeshes->DrawBoxMesh();
	}
	/****************************************************************/

	// the three shelves share the wood texture and material
	SetShaderTexture("wood");   // wood shelf
	// tile the wood 4 times across the long shelf so the grain is not stretched
	SetTextureUVScale(4.0f, 1.0f);
	SetShaderMaterial("wood");   // wood material for lighting

	// top surface of the bookshelf, sits at the top of the legs
	SetTransformations(
		glm::vec3(14.0f, 0.25f, 3.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 5.9f, 0.0f));
	m_basicMeshes->DrawBoxMesh();

	// middle shelf, the upper of the two book shelves
	SetTransformations(
		glm::vec3(13.5f, 0.2f, 2.8f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 3.6f, 0.0f));
	m_basicMeshes->DrawBoxMesh();

	// bottom shelf, sits just above the floor
	SetTransformations(
		glm::vec3(13.5f, 0.2f, 2.8f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 1.6f, 0.0f));
	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/
}

/***********************************************************
 *  DrawMetalRing()
 *
 *  This method is used for drawing the large black metal
 *  ring that stands in the center of the bookshelf
 ***********************************************************/
void SceneManager::DrawMetalRing()
{
	// metal ring, sits in front of the shelves
	// z of 1.55 clears the front edge of the shelves at 1.4
	SetTransformations(
		glm::vec3(2.6f, 2.6f, 2.6f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(0.0f, 3.0f, 1.55f));

	SetShaderTexture("metal");
	// wrap the metal around the ring a few times so it is not stretched
	SetTextureUVScale(4.0f, 1.0f);
	SetShaderMaterial("metal");   // metal material for lighting

	m_basicMeshes->DrawTorusMesh();
	/****************************************************************/
}

/***********************************************************
 *  DrawSandscape()
 *
 *  This method is used for drawing the round sandscape,
 *  a sand disk inside a metal frame on a small stand.
 *  The position is the spot on the shelf under the stand.
 ***********************************************************/
void SceneManager::DrawSandscape(glm::vec3 position)
{
	// center of the round frame, raised above the stand
	glm::vec3 center = glm::vec3(position.x, position.y + 1.15f, position.z);

	// small black stand the sandscape rests on
	SetTransformations(
		glm::vec3(0.9f, 0.15f, 0.5f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(position.x, position.y + 0.075f, position.z));
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawBoxMesh();

	// round metal frame, stretched on z so it has some depth
	SetTransformations(
		glm::vec3(1.0f, 1.0f, 2.0f),
		0.0f, 0.0f, 0.0f,
		center);
	SetTextureUVScale(2.0f, 1.0f);
	m_basicMeshes->DrawTorusMesh();

	// sand disk inside the frame, the cylinder is turned 90 on x
	// so it faces forward, then pulled back half its depth to center it
	SetTransformations(
		glm::vec3(0.95f, 0.08f, 0.95f),
		90.0f, 0.0f, 0.0f,
		glm::vec3(center.x, center.y, center.z - 0.04f));
	SetShaderColor(0.82f, 0.7f, 0.5f, 1.0f);   // light tan sand
	SetShaderMaterial("sand");
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/
}

/***********************************************************
 *  DrawPumpkinCandle()
 *
 *  This method is used for drawing one pumpkin candle,
 *  a squashed orange sphere with a small stem. The size
 *  lets the same function draw big and small pumpkins.
 ***********************************************************/
void SceneManager::DrawPumpkinCandle(glm::vec3 position, float size)
{
	// pumpkin body is flatter than it is wide
	float bodyHeight = size * 0.75f;

	// orange pumpkin body sitting on the shelf
	SetTransformations(
		glm::vec3(size, bodyHeight, size),
		0.0f, 0.0f, 0.0f,
		glm::vec3(position.x, position.y + bodyHeight, position.z));
	SetShaderColor(0.9f, 0.45f, 0.1f, 1.0f);   // pumpkin orange
	SetShaderMaterial("wax");
	m_basicMeshes->DrawSphereMesh();

	// short brown stem, starts just inside the top of the body
	SetTransformations(
		glm::vec3(size * 0.1f, size * 0.3f, size * 0.1f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(position.x, position.y + (bodyHeight * 2.0f) - 0.05f, position.z));
	SetShaderColor(0.35f, 0.22f, 0.1f, 1.0f);  // brown stem
	m_basicMeshes->DrawCylinderMesh();
	/****************************************************************/
}

/***********************************************************
 *  DrawCandleTray()
 *
 *  This method is used for drawing the black tray with
 *  three candle holders on it
 ***********************************************************/
void SceneManager::DrawCandleTray(glm::vec3 position)
{
	// thickness of the tray, the holders sit on top of it
	float trayHeight = 0.08f;

	// flat black metal tray
	SetTransformations(
		glm::vec3(2.6f, trayHeight, 1.0f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(position.x, position.y + (trayHeight / 2.0f), position.z));
	SetShaderTexture("metal");
	SetTextureUVScale(2.0f, 1.0f);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawBoxMesh();

	// three holders, the middle one is taller
	float trayTop = position.y + trayHeight;
	DrawCandleHolder(glm::vec3(position.x - 0.8f, trayTop, position.z), 0.3f);
	DrawCandleHolder(glm::vec3(position.x, trayTop, position.z), 0.45f);
	DrawCandleHolder(glm::vec3(position.x + 0.8f, trayTop, position.z), 0.3f);
	/****************************************************************/
}

/***********************************************************
 *  DrawCandleHolder()
 *
 *  This method is used for drawing one candle holder,
 *  a tapered metal base with a candle and flame on top.
 *  The height changes how tall the metal base is.
 ***********************************************************/
void SceneManager::DrawCandleHolder(glm::vec3 position, float height)
{
	// candle size, kept the same for every holder
	float candleHeight = 0.45f;
	float candleTop = position.y + height + candleHeight;

	// tapered metal base, wide at the bottom and narrow at the top
	SetTransformations(
		glm::vec3(0.18f, height, 0.18f),
		0.0f, 0.0f, 0.0f,
		position);
	SetShaderTexture("metal");
	SetTextureUVScale(1.0f, 1.0f);
	SetShaderMaterial("metal");
	m_basicMeshes->DrawTaperedCylinderMesh();

	// cream candle sitting in the top of the holder
	SetTransformations(
		glm::vec3(0.08f, candleHeight, 0.08f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(position.x, position.y + height, position.z));
	SetShaderColor(0.95f, 0.92f, 0.82f, 1.0f);   // cream wax
	SetShaderMaterial("wax");
	m_basicMeshes->DrawCylinderMesh();

	// small yellow flame stretched up into a teardrop
	SetTransformations(
		glm::vec3(0.035f, 0.08f, 0.035f),
		0.0f, 0.0f, 0.0f,
		glm::vec3(position.x, candleTop + 0.07f, position.z));
	SetShaderColor(1.0f, 0.8f, 0.3f, 1.0f);   // flame yellow
	m_basicMeshes->DrawSphereMesh();
	/****************************************************************/
}

/***********************************************************
 *  DrawBook()
 *
 *  This method is used for drawing one book as a colored
 *  box. Size is the thickness, height and depth.
 ***********************************************************/
void SceneManager::DrawBook(glm::vec3 size, glm::vec3 position, glm::vec4 color)
{
	SetTransformations(
		size,
		0.0f, 0.0f, 0.0f,
		position);
	SetShaderColor(color.r, color.g, color.b, color.a);
	SetShaderMaterial("book");
	m_basicMeshes->DrawBoxMesh();
}

/***********************************************************
 *  DrawBookRow()
 *
 *  This method is used for filling a shelf with standing
 *  books from startX to endX. Books keep getting added
 *  until the next one would not fit. Pattern shifts the
 *  sizes and colors so each shelf looks different.
 ***********************************************************/
void SceneManager::DrawBookRow(float startX, float endX, float shelfY, int pattern)
{
	const int bookCount = 8;

	// book sizes and cover colors to pick from
	float heights[bookCount] = { 1.5f, 1.3f, 1.6f, 1.4f, 1.55f, 1.25f, 1.45f, 1.35f };
	float widths[bookCount] = { 0.3f, 0.25f, 0.35f, 0.28f, 0.32f, 0.22f, 0.4f, 0.26f };
	glm::vec4 colors[bookCount] = {
		glm::vec4(0.15f, 0.25f, 0.18f, 1.0f),   // dark green
		glm::vec4(0.12f, 0.15f, 0.3f, 1.0f),    // navy
		glm::vec4(0.45f, 0.12f, 0.12f, 1.0f),   // maroon
		glm::vec4(0.85f, 0.8f, 0.68f, 1.0f),    // cream
		glm::vec4(0.75f, 0.55f, 0.15f, 1.0f),   // mustard
		glm::vec4(0.1f, 0.1f, 0.1f, 1.0f),      // black
		glm::vec4(0.35f, 0.2f, 0.12f, 1.0f),    // brown
		glm::vec4(0.55f, 0.6f, 0.62f, 1.0f)     // gray blue
	};

	// x is the left edge of the next book
	float x = startX;
	int i = 0;

	while (true)
	{
		// stepping by 3 mixes up the order so neighbors are not
		// always the same, and the pattern changes the starting book
		int index = ((i * 3) + pattern) % bookCount;
		float width = widths[index];
		float height = heights[index];

		// stop when the next book would go past the end of the shelf
		if (x + width > endX)
		{
			break;
		}

		// box is centered so half the width and height set it in place
		DrawBook(
			glm::vec3(width, height, 1.8f),
			glm::vec3(x + (width / 2.0f), shelfY + (height / 2.0f), 0.0f),
			colors[index]);

		// move past this book plus a small gap for the next one
		x += width + 0.02f;
		i++;
	}
}

/***********************************************************
 *  DrawBookStack()
 *
 *  This method is used for drawing a short stack of books
 *  lying flat on a shelf
 ***********************************************************/
void SceneManager::DrawBookStack(glm::vec3 position)
{
	const int bookCount = 3;
	float thickness = 0.22f;

	// each book is a little smaller than the one below it
	glm::vec3 sizes[bookCount] = {
		glm::vec3(1.8f, thickness, 1.3f),
		glm::vec3(1.6f, thickness, 1.2f),
		glm::vec3(1.4f, thickness, 1.1f)
	};
	glm::vec4 colors[bookCount] = {
		glm::vec4(0.45f, 0.12f, 0.12f, 1.0f),   // maroon
		glm::vec4(0.85f, 0.8f, 0.68f, 1.0f),    // cream
		glm::vec4(0.15f, 0.25f, 0.18f, 1.0f)    // dark green
	};

	for (int i = 0; i < bookCount; i++)
	{
		// stack each book on top of the one before it
		float y = position.y + (thickness / 2.0f) + (i * thickness);
		DrawBook(sizes[i], glm::vec3(position.x, y, position.z), colors[i]);
	}
}